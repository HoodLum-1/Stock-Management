package za.co.sithole.clinicapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
